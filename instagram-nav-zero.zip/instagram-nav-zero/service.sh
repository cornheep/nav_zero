#!/system/bin/sh
# Enable overlay on boot
sleep 5
cmd overlay enable com.instagram.android.InstagramNavFixOverlay 2>/dev/null
